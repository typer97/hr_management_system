<?php
include 'config.php';
session_start();

if ($_SESSION['role'] != 'boss') {
    header("Location: login.php");
    exit();
}

$tasks = mysqli_query($conn, "SELECT tasks.*, users.username as employee_name FROM tasks LEFT JOIN users ON tasks.assigned_to = users.id");
$employees = mysqli_query($conn, "SELECT * FROM users WHERE role='employee'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Boss Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="container">
        <div id="branding">
            <h1>HR Management System</h1>
        </div>
        <nav>
            <ul>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
</header>
<div class="container">
    <h2>Boss Dashboard</h2>
    <h3>Assign Task</h3>
    <form action="app/add.php" method="post">
        <label>Title:</label><br>
        <input type="text" name="title" required><br>
        <label>Description:</label><br>
        <textarea name="description" required></textarea><br>
        <label>Assign To:</label><br>
        <select name="assigned_to" required>
            <?php while ($employee = mysqli_fetch_assoc($employees)): ?>
                <option value="<?php echo $employee['id']; ?>"><?php echo $employee['username']; ?></option>
            <?php endwhile; ?>
        </select><br><br>
        <input type="submit" value="Assign Task">
    </form>

    <h3>Tasks</h3>
    <table>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Assigned To</th>
            <th>Assigned At</th>
            <th>Status</th>
            <th>Completed At</th>
            <th>Actions</th>
        </tr>
        <?php while ($task = mysqli_fetch_assoc($tasks)): ?>
            <tr>
                <td><?php echo $task['title']; ?></td>
                <td><?php echo $task['description']; ?></td>
                <td><?php echo $task['employee_name']; ?></td>
                <td><?php echo $task['assigned_at']; ?></td>
                <td><?php echo $task['status']; ?></td>
                <td><?php echo $task['completed_at']; ?></td>
                <td>
                    <a href="app/check.php?id=<?php echo $task['id']; ?>">Toggle Status</a>
                    <a href="app/remove.php?id=<?php echo $task['id']; ?>">Remove</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
