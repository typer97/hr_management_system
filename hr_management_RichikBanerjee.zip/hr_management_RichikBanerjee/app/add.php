<?php
include '../config.php';
session_start();

if ($_SESSION['role'] != 'boss') {
    header("Location: ../login.php");
    exit();
}

if (isset($_POST['title'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $assigned_to = $_POST['assigned_to'];
    $assigned_by = $_SESSION['user_id'];
    $assigned_at = date('Y-m-d H:i:s');

    $sql = "INSERT INTO tasks (title, description, assigned_to, assigned_by, assigned_at) VALUES ('$title', '$description', '$assigned_to', '$assigned_by', '$assigned_at')";
    if (mysqli_query($conn, $sql)) {
        header("Location: ../boss_dashboard.php?success=Task added successfully");
    } else {
        header("Location: ../boss_dashboard.php?error=Error adding task");
    }
} else {
    header("Location: ../boss_dashboard.php?error=Title is required");
}
?>
