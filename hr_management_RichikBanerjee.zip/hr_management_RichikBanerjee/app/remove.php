<?php
include '../config.php';
session_start();

if (!isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM tasks WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        header("Location: ../boss_dashboard.php?success=Task deleted successfully");
    } else {
        header("Location: ../boss_dashboard.php?error=Error deleting task");
    }
} else {
    header("Location: ../boss_dashboard.php?error=ID is required");
}
?>
