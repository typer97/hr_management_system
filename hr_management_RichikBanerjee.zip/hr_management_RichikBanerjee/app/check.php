<?php
include '../config.php';
session_start();

if (!isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM tasks WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    $task = mysqli_fetch_assoc($result);

    if ($task) {
        $newStatus = $task['status'] == 'pending' ? 'done' : 'pending';
        $completedAt = $newStatus == 'done' ? date('Y-m-d H:i:s') : null;

        $sql = "UPDATE tasks SET status='$newStatus', completed_at='$completedAt' WHERE id=$id";
        if (mysqli_query($conn, $sql)) {
            header("Location: ../boss_dashboard.php?success=Task status updated");
        } else {
            header("Location: ../boss_dashboard.php?error=Error updating status");
        }
    } else {
        header("Location: ../boss_dashboard.php?error=Task not found");
    }
} else {
    header("Location: ../boss_dashboard.php?error=ID is required");
}
?>
