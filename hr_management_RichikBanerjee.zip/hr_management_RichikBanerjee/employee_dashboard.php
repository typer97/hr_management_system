<?php
include 'config.php';
session_start();

if ($_SESSION['role'] != 'employee') {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];
$tasks = mysqli_query($conn, "SELECT * FROM tasks WHERE assigned_to = $userId");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="container">
        <div id="branding">
            <h1>HR Management System</h1>
        </div>
        <nav>
            <ul>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </div>
</header>
<div class="container">
    <h2>Employee Dashboard</h2>
    <h3>Tasks</h3>
    <table>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Assigned At</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php while ($task = mysqli_fetch_assoc($tasks)): ?>
            <tr>
                <td><?php echo $task['title']; ?></td>
                <td><?php echo $task['description']; ?></td>
                <td><?php echo $task['assigned_at']; ?></td>
                <td><?php echo $task['status']; ?></td>
                <td>
                    <a href="app/check.php?id=<?php echo $task['id']; ?>">Toggle Status</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
