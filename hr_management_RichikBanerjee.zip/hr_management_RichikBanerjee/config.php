<?php
$sName = "localhost";
$uName = "root";
$pass = "";
$db_name = "hr_management_system";

try {
    $conn = new mysqli($sName, $uName, $pass, $db_name);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    echo $e->getMessage();
    exit();
}
?>
